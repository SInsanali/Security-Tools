Function Get-LogVariables {
    $LogComponent = "Evaluate-STIG Update"

    If ($IsLinux) {
        $OSPlatform = "Linux"
        $UpdateLogDir = "/tmp/Evaluate-STIG"
    }
    Else {
        $OSPlatform = "Windows"
        $UpdateLogDir = Join-Path -Path (Get-Item $env:TEMP).FullName -ChildPath "Evaluate-STIG"
    }
    $UpdateLog = Join-Path -Path $UpdateLogDir -ChildPath "Evaluate-STIG_Update.log"

    $LogVars = [PSCustomObject]@{
        UpdateLog    = $UpdateLog
        LogComponent = $LogComponent
        OSPlatform   = $OSPlatform
    }

    Return $LogVars
}

Function Start-UpdateCleanup {
    Param (
        [Parameter(Mandatory = $false)]
        [String] $Update_tmp,

        [Parameter(Mandatory = $false)]
        [String] $Backup_tmp,

        [Parameter(Mandatory = $false)]
        [String] $ZipFile
    )

    Try {
        $Log = Get-LogVariables
        Write-Log -Path $Log.UpdateLog -Message "Cleaning up..." -WriteOutToStream -FGColor Gray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform

        If ($Update_tmp) {
            # Clean up temp files
            If (Test-Path $Update_tmp) {
                Write-Log -Path $Log.UpdateLog -Message "Removing '$Update_tmp'" -WriteOutToStream -FGColor DarkGray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform
                Remove-Item -Path $Update_tmp -Recurse -Force -ErrorAction Stop
            }
        }

        If ($Backup_tmp) {
            # Clean up temp files
            If (Test-Path $Backup_tmp) {
                Write-Log -Path $Log.UpdateLog -Message "Removing '$Backup_tmp'" -WriteOutToStream -FGColor DarkGray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform
                Remove-Item -Path $Backup_tmp -Recurse -Force -ErrorAction Stop
            }
        }

        If ($ZipFile) {
            If (Test-Path $ZipFile) {
                Write-Log -Path $Log.UpdateLog -Message "Removing '$ZipFile'" -WriteOutToStream -FGColor DarkGray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform
                If ($Zip) {
                    $Zip.Dispose()
                }
                If (Wait-FileUnlock -Path $ZipFile -GetLockingProcess Yes) {
                    Write-Log -Path $Log.UpdateLog -Message "'$ZipFile' is currently locked by another process.  Waiting for release..." -WriteOutToStream -Component $Log.LogComponent -Type "Warning" -OSPlatform $Log.OSPlatform
                    Wait-FileUnlock -Path $ZipFile -ErrorAction Stop
                }
                Remove-Item $ZipFile -Force -ErrorAction Stop
            }
        }
    }
    Catch {
        Throw $_
    }
}

Function Start-EvalSTIGUpdate {
    Param (
        [Parameter(Mandatory = $true)]
        [String] $PS_Path,

        [Parameter(Mandatory = $false)]
        [String] $Proxy,

        [Parameter(Mandatory = $false)]
        [Switch] $ResumeUpdate,

        [Parameter(Mandatory = $false)]
        [String] $LocalSource
    )

    Try {
        $Update_tmp = (Join-Path -Path $PS_Path -ChildPath "_Update.tmp")
        $Backup_tmp = (Join-Path -Path $PS_Path -ChildPath "_Backup.tmp")

        # Prep for logging
        $Log = Get-LogVariables
        $UpdateLogDir = Split-Path ($Log).UpdateLog -Parent
        If (-Not(Test-Path $UpdateLogDir)) {
            $null = New-Item -Path $UpdateLogDir -ItemType Directory -ErrorAction Stop
        }

        If (Test-Path $Log.UpdateLog) {
            If ((Get-Item $Log.UpdateLog).Length -gt 1mb -and (-Not($ResumeUpdate))) {
                # Remove the log if over 1 MB and start new
                Remove-Item $Log.UpdateLog -Force
            }
        }

        # Get local content inventory
        $LocalVersion = (Select-String -Path $(Join-Path -Path $PS_Path -ChildPath "Evaluate-STIG.ps1") -Pattern '\$EvaluateStigVersion = ' | ForEach-Object { $_.Line.Split(":") }).replace('$EvaluateStigVersion = ', '').Replace('"', '').Trim()
        $LocalContent = Get-ChildItem $PS_Path -Recurse | Where-Object FullName -NotMatch "(powershell\.tar\.gz|AnswerFiles|_Update\.tmp|_Backup\.tmp)"
        If (Test-Path $(Join-Path -Path $PS_Path -ChildPath "AnswerFiles" | Join-Path -ChildPath "Template_AnswerFile.xml")) {
            # Add template answer file for compare
            $LocalContent += Get-ChildItem $(Join-Path -Path $PS_Path -ChildPath "AnswerFiles" | Join-Path -ChildPath "Template_AnswerFile.xml")
        }
        [XML]$FileListXML = Get-Content ($LocalContent | Where-Object { $_.Name -eq "FileList.XML" }).FullName
        $LocalContentList = New-Object System.Collections.Generic.List[System.Object]
        ForEach ($Item in $LocalContent) {
            If ($Item.PSIsContainer -eq $true) {
                $Hash = ""
            }
            Else {
                $OptXccdfPattern = "^CUI_.+V\dR\d.+xccdf\.xml$"
                If ($Item.Name -match $OptXccdfPattern) {
                    $FileListAttributes = $FileListXML.FileList.File | Where-Object Name -match $OptXccdfPattern
                }
                Else {
                    $FileListAttributes = $FileListXML.FileList.File | Where-Object Name -eq $Item.Name
                }

                If ($FileListAttributes.Path -match "Modules") {
                    $IsModule = $True
                }
                Else {
                    $IsModule = $False
                }
                $ScanReq = $FileListAttributes.ScanReq
                $Hash = (Get-FileHash $Item.FullName -Algorithm SHA256).Hash

            }
            $NewObj = [PSCustomObject]@{
                PSIsContainer = $Item.PSIsContainer
                Name          = $Item.Name
                FullName      = $Item.FullName
                IsModule      = $IsModule
                ScanRequired  = $ScanReq
                Hash          = $Hash
            }
            $LocalContentList.Add($NewObj)
        }

        # Begin updating
        If (-Not($ResumeUpdate)) {
            $UpdateRequired = $false

            Write-Host "Logging to '$($Log.UpdateLog)'" -ForegroundColor Cyan
            Write-Host ""
            Write-Log -Path $Log.UpdateLog -Message "Begin Update" -TemplateMessage LineBreak-Text -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform

            # Clean up temp files
            If (Test-Path $Update_tmp) {
                Write-Log -Path $Log.UpdateLog -Message "Removing orphaned '$Update_tmp'" -WriteOutToStream -FGColor DarkGray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform
                Remove-Item -Path $Update_tmp -Recurse -Force -ErrorAction Stop
            }

            # Clean up backup files
            If (Test-Path $Backup_tmp) {
                Write-Log -Path $Log.UpdateLog -Message "Removing orphaned '$Backup_tmp'" -WriteOutToStream -FGColor DarkGray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform
                Remove-Item -Path $Backup_tmp -Recurse -Force -ErrorAction Stop
            }

            If ($LocalSource) {
                #Validate LocalSource content
                $Verified = $true
                $LocalSource = $PSBoundParameters.LocalSource
                If (Test-Path (Join-Path -Path $LocalSource -ChildPath "xml" | Join-Path -ChildPath "FileList.xml")) {
                    [XML]$FileListXML = Get-Content -Path (Join-Path -Path $LocalSource -ChildPath "xml" | Join-Path -ChildPath "FileList.xml")
                    If ((Test-XmlSignature -checkxml $FileListXML -Force) -ne $true) {
                        Throw "'FileList.xml' in '$LocalSource' failed authenticity check.  Unable to verify content integrity."
                    }
                    Else {
                        ForEach ($File in $FileListXML.FileList.File) {
                            $Path = (Join-Path -Path $LocalSource -ChildPath $File.Path | Join-Path -ChildPath $File.Name)
                            If (Test-Path $Path) {
                                If ((Get-FileHash -Path $Path -Algorithm SHA256).Hash -ne $File.SHA256Hash) {
                                    $Verified = $false
                                }
                            }
                            Else {
                                If ($File.ScanReq -ne "Optional") {
                                    $Verified = $false
                                }
                            }
                        }
                        If ($Verified -eq $true) {
                            Write-Log -Path $Log.UpdateLog -Message "'$LocalSource' file integrity check passed." -WriteOutToStream -FGColor Green -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform
                        }
                        Else {
                            Throw "'$LocalSource' file integrity check failed."
                        }
                    }
                }
                Else {
                    Throw "'FileList.xml' in '$LocalSource' not found.  Unable to verify content integrity."
                }
            }


            Write-Log -Path $Log.UpdateLog -Message "Checking for updates to Evaluate-STIG" -WriteOutToStream -FGColor Gray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform

            If ($Proxy) {
                Write-Log -Path $Log.UpdateLog -Message "Using proxy '$Proxy'" -WriteOutToStream -FGColor DarkGray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform
            }

            # Create temp folder
            If (Test-Path $Update_tmp) {
                Remove-Item $Update_tmp -Recurse -Force
            }
            $null = New-Item -Path $PS_Path -Name "_Update.tmp" -ItemType Directory

            If ($LocalSource) {
                Write-Log -Path $Log.UpdateLog -Message "Using Local Source '$LocalSource'" -WriteOutToStream -FGColor DarkGray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform
                Copy-Item -Path "$LocalSource\*" -Destination $Update_tmp -Recurse
            }
            Else {
                $URLs = @(
                    "https://spork.navsea.navy.mil/nswc-crane-division/evaluate-stig/-/archive/master/evaluate-stig-master.zip?path=Src/Evaluate-STIG"
                )

                # load ZIP methods
                Add-Type -AssemblyName System.IO.Compression.FileSystem

                # Download upstream content
                Write-Log -Path $Log.UpdateLog -Message "Downloading content from upstream" -WriteOutToStream -FGColor DarkGray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform
                $ZipFile = $(Join-Path -Path $PS_Path -ChildPath "evaluate-stig-master.zip")
                If ($Islinux) {
                    $pkg_mgr = (Get-Content /etc/os-release | grep "ID_LIKE=").replace("ID_LIKE=", "").replace('"', "")
                    Switch ($pkg_mgr) {
                        "debian" {
                            If (apt -qq list curl 2>/dev/null | grep installed) {
                                $curl_installed = $true
                            }
                        }
                        "fedora" {
                            If (rpm -qa | grep curl) {
                                $curl_installed = $true
                            }
                        }
                    }
                    If ($curl_installed) {
                        ForEach ($URL in $URLs) {
                            If ($Proxy) {
                                curl -k $URL --proxy $Proxy --output evaluate-stig-master.zip
                            }
                            Else {
                                curl -k $URL --output evaluate-stig-master.zip
                            }
                            If ((Get-Item $ZipFile).Length -gt 0) {
                                Break
                            }
                        }
                    }
                    Else {
                        Throw "Curl is required to be installed to download updates."
                    }
                }
                Else {
                    $WebClient = New-Object System.Net.WebClient
                    If ($Proxy) {
                        $WebProxy = New-Object System.Net.WebProxy($Proxy, $true)
                        $WebClient.Proxy = $WebProxy
                    }
                    ForEach ($URL in $URLs) {
                        $WebClient.DownloadFile($URL, $ZipFile)
                        If ((Get-Item $ZipFile).Length -gt 0) {
                            Break
                        }
                    }
                }

                # change extension filter to a file extension that exists
                # inside your ZIP file
                $Filter = '/Evaluate-STIG/'

                # Unblock and open ZIP archive for reading
                If (Wait-FileUnlock -Path $ZipFile -GetLockingProcess Yes) {
                    Write-Log -Path $Log.UpdateLog -Message "'$ZipFile' is currently locked by another process.  Waiting for release..." -WriteOutToStream -Component $Log.LogComponent -Type "Warning" -OSPlatform $Log.OSPlatform
                    Wait-FileUnlock -Path $ZipFile -ErrorAction Stop
                }
                If ($Log.OSPlatform -eq "Windows") {
                    Unblock-File -Path $ZipFile
                }
                $Zip = [IO.Compression.ZipFile]::OpenRead($ZipFile)

                # find all files in ZIP that match the filter (i.e. file extension)
                $Zip.Entries |
                Where-Object {$_.FullName -match $Filter} | ForEach-Object {
                    # extract the selected items from the ZIP archive
                    # and copy them to the out folder
                    $FileName = $_.Name
                    If ($Filename) {
                        $Path_strip = ($_.FullName).replace("evaluate-stig-master-Src-Evaluate-STIG/Src/Evaluate-STIG", "").Replace($FileName, "")
                        $FilePath = "$(Join-Path -Path $Update_tmp -ChildPath $Path_strip)"
                        [IO.Compression.ZipFileExtensions]::ExtractToFile($_, "$FilePath$FileName", $true)
                    }
                    Else {
                        $Path_strip = ($_.FullName).replace("evaluate-stig-master-Src-Evaluate-STIG/Src/Evaluate-STIG", "")
                        $null = New-Item -Path $(Join-Path -Path $Update_tmp -ChildPath $Path_strip) -ItemType Directory -Force
                    }
                }
                # close ZIP file
                $Zip.Dispose()
                Remove-Item -Path $ZipFile -Force
            }

            # Get upstream content inventory
            $UpstreamVersion = (Select-String -Path $(Join-Path -Path $Update_tmp -ChildPath "Evaluate-STIG.ps1") -Pattern '\$EvaluateStigVersion = ' | ForEach-Object { $_.Line.Split(":") }).replace('$EvaluateStigVersion = ', '').Replace('"', '').Trim()
            $UpstreamContent = Get-ChildItem $Update_tmp -Recurse
            [XML]$FileListXML = Get-Content ($UpstreamContent | Where-Object { $_.Name -eq "FileList.XML" }).FullName
            $UpstreamContentList = New-Object System.Collections.Generic.List[System.Object]
            ForEach ($Item in $UpstreamContent) {
                If ($Item.PSIsContainer -eq $true) {
                    $Hash = ""
                }
                Else {
                    $FileListAttributes = (Select-Xml -Xml $FileListXML -XPath "//File[@Name=""$($Item.Name)""]").Node
                    If ($FileListAttributes.Path -match "Modules") {
                        $IsModule = $True
                    }
                    Else {
                        $IsModule = $False
                    }
                    $ScanReq = $FileListAttributes.ScanReq
                    If ($Item.Name -eq "FileList.xml") {
                        $Hash = (Get-FileHash $Item.FullName -Algorithm SHA256).Hash
                    }
                    Else {
                        $Hash = $FileListAttributes.SHA256Hash
                    }
                }
                $NewObj = [PSCustomObject]@{
                    PSIsContainer = $Item.PSIsContainer
                    Name          = $Item.Name
                    FullName      = $Item.FullName
                    IsModule      = $IsModule
                    ScanRequired  = $ScanReq
                    Hash          = $Hash
                }
                $UpstreamContentList.Add($NewObj)
            }

            # Compare local file hashes to upstream hashes
            ForEach ($Item in ($UpstreamContentList | Where-Object {$_.PSIsContainer -NE $true -and $_.Name -NE "Preferences.xml"})) {
                $LocalFile = $Item.FullName.Replace($Update_tmp, $PS_Path)
                If (-Not((Test-Path $LocalFile) -and (($LocalContentList | Where-Object FullName -EQ $LocalFile).Hash -eq $Item.Hash))) {
                    If ($UpdateRequired -ne $true) {
                        $UpdateRequired = $true
                    }
                    Break
                }
            }

            # Look for items that are not part of upstream content (exclude Optional files)
            ForEach ($Item in $LocalContentList | Where-Object {$_.PSIsContainer -ne $true -and $_.ScanRequired -ne "Optional"}) {
                If ((Test-Path $Item.FullName) -and ($Item.FullName -notin $UpstreamContentList.FullName.Replace($Update_tmp, $PS_Path))) {
                    If ($UpdateRequired -ne $true) {
                        $UpdateRequired = $true
                    }
                    Break
                }
            }

            # If Answer Files folder doesn't exist, mark for updating
            If (-Not(Test-Path $(Join-Path -Path $PS_Path -ChildPath "AnswerFiles"))) {
                $UpdateRequired = $true
            }

            If ($UpdateRequired -eq $true) {
                $Message = "'$PS_Path' core files require updating"
            }
            Else {
                $Message = "'$PS_Path' core files are current"

                # Check that any optional content is current
                ForEach ($File in ($FileListXML.FileList.File | Where-Object ScanReq -eq "Optional")) {
                    $Path = (Join-Path -Path $PS_Path -ChildPath $File.Path | Join-Path -ChildPath $File.Name)
                    If (Test-Path $Path) {
                        If ((Get-FileHash -Path $Path -Algorithm SHA256).Hash -ne $File.SHA256Hash) {
                            Write-Log -Path $Log.UpdateLog -Message "Optional file '$($File.Name)' is not current and requires manual update" -WriteOutToStream -Component $Log.LogComponent -Type "Warning" -OSPlatform $Log.OSPlatform
                        }
                    }
                    Else {
                        $OptXccdfPattern = "^CUI_.+V\dR\d.+xccdf\.xml$"
                        If ($File.Name -match $OptXccdfPattern) {
                            $OptFile = Get-ChildItem -Path $PS_Path -Recurse -File | Where-Object {$_.Name -match $OptXccdfPattern -and $_.FullName -notmatch "(_Update\.tmp|_Backup\.tmp)"}
                            If ($OptFile) {
                                Write-Log -Path $Log.UpdateLog -Message "Optional file '$($OptFile.Name)' is not current and requires manual update" -WriteOutToStream -Component $Log.LogComponent -Type "Warning" -OSPlatform $Log.OSPlatform
                            }
                        }
                    }
                }
            }
        }
        ElseIf ($ResumeUpdate) {
            $UpdateRequired = $true
            $BackedUp = $false
            $UpstreamVersion = (Select-String -Path $(Join-Path -Path $Update_tmp -ChildPath "Evaluate-STIG.ps1") -Pattern '\$EvaluateStigVersion = ' | ForEach-Object { $_.Line.Split(":") }).replace('$EvaluateStigVersion = ', '').Replace('"', '').Trim()

            Write-Log -Path $Log.UpdateLog -Message "Preparing for update to Evaluate-STIG $UpstreamVersion..." -WriteOutToStream -FGColor Gray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform

            # Back up current content
            Write-Log -Path $Log.UpdateLog -Message "Backing up current content" -WriteOutToStream -FGColor DarkGray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform
            $CurrentContent = Get-ChildItem $PS_Path | Where-Object Name -NotMatch "(\.zip|_Update\.tmp|_Backup\.tmp)"
            If (-Not(Test-Path $Backup_tmp)) {
                $null = New-Item -Path $Backup_tmp -ItemType Directory -ErrorAction Stop
            }
            $CurrentContent | ForEach-Object {Copy-Item $_.FullName -Recurse -Destination $Backup_tmp -ErrorAction Stop}
            $BackedUp = $true

            # ReWrite Local Preferences to Updated Preferences File
            Write-Log -Path $Log.UpdateLog -Message "Updating 'Preferences.xml'" -WriteOutToStream -FGColor DarkGray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform
            $LocalPreferences = (Select-Xml -Path $(Join-Path $PS_Path -ChildPath Preferences.xml) -XPath /).Node
            $UpstreamPreferences = (Select-Xml -Path $(Join-Path $Update_tmp -ChildPath Preferences.xml) -XPath /).Node
            Foreach ($RootNode in $LocalPreferences.SelectNodes("//*")) {
                $RootNode.SelectNodes("./*[not(*)]") | ForEach-Object {
                    If ($null -ne $_.'#text') {
                        If ($($UpstreamPreferences.SelectSingleNode(".//$($_.Name)"))) {
                            ($UpstreamPreferences.SelectSingleNode(".//$($_.Name)")).InnerText = $_."#text"
                        }
                    }
                }
            }
            $UpstreamPreferences.Save($(Join-Path $Update_tmp -ChildPath Preferences.xml))

            # Note optional modules that will need restored and remove existing content
            $OptionalList = New-Object System.Collections.Generic.List[System.Object]
            ForEach ($Item in $LocalContentList) {
                If ($Item.ScanRequired -eq "Optional") {
                    $OptionalList.Add($Item)
                }
                If (Test-Path $Item.FullName) {
                    Remove-Item $Item.FullName -Recurse -Force -ErrorVariable Stop
                }
            }

            # If Answer Files folder doesn't exist for some reason, create it since it's the default for -AFPath
            If (-Not(Test-Path $(Join-Path -Path $PS_Path -ChildPath "AnswerFiles"))) {
                Write-Log -Path $Log.UpdateLog -Message "Recreating 'AnswerFiles' folder" -WriteOutToStream -FGColor DarkGray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform
                New-Item -Path $PS_Path -Name "AnswerFiles" -ItemType Directory -ErrorAction Stop | Out-Null
            }

            # Copy Evaluate-STIG files from upstream content
            Write-Log -Path $Log.UpdateLog -Message "Updating Evaluate-STIG files" -WriteOutToStream -FGColor DarkGray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform
            Copy-Item $(Join-Path -Path $Update_tmp -ChildPath "*") -Recurse -Destination $PS_Path -Force -ErrorAction Stop

            If (Test-Path (Join-Path -Path $PS_Path -ChildPath "xml" | Join-Path -ChildPath "FileList.xml")) {
                [XML]$FileListXML = Get-Content -Path (Join-Path -Path $PS_Path -ChildPath "xml" | Join-Path -ChildPath "FileList.xml")
                If ((Test-XmlSignature -checkxml $FileListXML -Force) -ne $true) {
                    Throw "'FileList.xml' in '$PS_Path' failed authenticity check after update.  Unable to verify content integrity."
                }
                Else {
                    # If needed, restore optional files
                    If ($OptionalList) {
                        # Get list of Optional files from new FileList
                        ForEach ($File in ($FileListXML.FileList.File | Where-Object ScanReq -eq "Optional")) {
                            $Path = (Join-Path -Path $PS_Path -ChildPath $File.Path | Join-Path -ChildPath $File.Name)
                            If (-Not(Test-Path $Path)) {
                                # Restore matching file from backup
                                $PreviousFile = Get-ChildItem -Path $Backup_tmp -Recurse -File | Where-Object Name -Like "$(($File.Name -split "V\dR\d")[0])*"
                                If ($PreviousFile) {
                                    Write-Log -Path $Log.UpdateLog -Message "Restoring previously existing optional file: $($PreviousFile.Name)" -WriteOutToStream -FGColor DarkGray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform
                                    If (-Not(Test-Path $(Join-Path -Path $PS_Path -ChildPath $File.Path))) {
                                        # Create folder
                                        $null = New-Item -Path $(Join-Path -Path $PS_Path -ChildPath $File.Path) -ItemType Directory -ErrorAction Stop
                                    }
                                    Copy-Item -Path $PreviousFile.FullName -Destination $(Join-Path -Path $PS_Path -ChildPath $File.Path | Join-Path -ChildPath $PreviousFile.Name) -ErrorAction Stop
                                }
                            }
                        }

                    }

                    $Verified = $true
                    ForEach ($File in $FileListXML.FileList.File) {
                        $Path = (Join-Path -Path $PS_Path -ChildPath $File.Path | Join-Path -ChildPath $File.Name)
                        If (Test-Path $Path) {
                            If ((Get-FileHash -Path $Path -Algorithm SHA256).Hash -ne $File.SHA256Hash) {
                                If ($File.ScanReq -eq "Optional") {
                                    Write-Log -Path $Log.UpdateLog -Message "Optional file '$($File.Name)' is not current and requires manual update" -WriteOutToStream -Component $Log.LogComponent -Type "Warning" -OSPlatform $Log.OSPlatform
                                }
                                Else {
                                    $Verified = $false
                                }
                            }
                        }
                        Else {
                            $OptXccdfPattern = "^CUI_.+V\dR\d.+xccdf\.xml$"
                            If ($File.Name -match $OptXccdfPattern) {
                                $OptFile = Get-ChildItem -Path $PS_Path -Recurse -File | Where-Object {$_.Name -match $OptXccdfPattern -and $_.FullName -notmatch "(_Update\.tmp|_Backup\.tmp)"}
                                If ($OptFile) {
                                    Write-Log -Path $Log.UpdateLog -Message "Optional file '$($OptFile.Name)' is not current and requires manual update" -WriteOutToStream -Component $Log.LogComponent -Type "Warning" -OSPlatform $Log.OSPlatform
                                }
                            }
                            If ($File.ScanReq -ne "Optional") {
                                $Verified = $false
                            }
                        }
                    }
                    If ($Verified -eq $true) {
                        $UpdateRequired = $false
                        $Message = "Successfully updated Evaluate-STIG core files to $($UpstreamVersion)"
                    }
                    Else {
                        Throw "'$PS_Path' file integrity check failed after update."
                    }
                }
            }
            Else {
                Throw "'FileList.xml' in $PS_Path not found after update.  Unable to verify content integrity."
            }
        }

        If (-Not($UpdateRequired)) {
            # Clean up
            Start-UpdateCleanup -Update_tmp $Update_tmp -Backup_tmp $Backup_tmp -ZipFile $ZipFile
        }

        # Build and return Result object
        $Result = [PSCustomObject]@{
            UpdateRequired  = $UpdateRequired
            LocalVersion    = $LocalVersion
            UpstreamVersion = $UpstreamVersion
            Message         = $Message
        }
        Return $Result
    }
    Catch {
        Write-Log -Path $Log.UpdateLog -Message "Error Detected" -WriteOutToStream -Component $Log.LogComponent -Type "Error" -OSPlatform $Log.OSPlatform
        # Get Error Data
        $ErrorData = $_ | Get-ErrorInformation
        If (Test-Path $Log.UpdateLog) {
            ForEach ($Item in ($ErrorData.PSObject.Properties).Name) {
                Write-Log -Path $Log.UpdateLog -Message "$($Item) : $($ErrorData.$Item)" -Component $Log.LogComponent -Type "Error" -OSPlatform $Log.OSPlatform
            }
        }

        # Restore from backup
        If ($BackedUp) {
            # Get inventories of bad update content and backup content
            Write-Log -Path $Log.UpdateLog -Message "Restoring backed up files" -WriteOutToStream -FGColor DarkGray -Component $Log.LogComponent -Type "Info" -OSPlatform $Log.OSPlatform
            $BadContent = Get-ChildItem $PS_Path | Where-Object Name -NotMatch "_Backup\.tmp"
            $BackupContent = Get-ChildItem $Backup_tmp

            # Remove bad content
            $BadContent | ForEach-Object {Remove-Item $_.FullName -Recurse -Force}

            # Restore from backup
            $BackupContent | ForEach-Object {Copy-Item $_.FullName -Recurse -Destination $PS_Path}
        }

        # Clean up
        Start-UpdateCleanup -Update_tmp $Update_tmp -Backup_tmp $Backup_tmp -ZipFile $ZipFile

        Throw $_
    }
}

# SIG # Begin signature block
# MIIL+QYJKoZIhvcNAQcCoIIL6jCCC+YCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDaP8u6gSm3YUmc
# x9PXiBQNQv/bqVTQFjzqwNagHrsqL6CCCTswggR6MIIDYqADAgECAgQDAgTXMA0G
# CSqGSIb3DQEBCwUAMFoxCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVy
# bm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0Qg
# SUQgQ0EtNTkwHhcNMjAwNzE1MDAwMDAwWhcNMjUwNDAyMTMzODMyWjBpMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMRYwFAYDVQQDEw1DUy5OU1dDQ0Qu
# MDAxMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2/Z91ObHZ009DjsX
# ySa9T6DbT+wWgX4NLeTYZwx264hfFgUnIww8C9Mm6ht4mVfo/qyvmMAqFdeyhXiV
# PZuhbDnzdKeXpy5J+oxtWjAgnWwJ983s3RVewtV063W7kYIqzj+Ncfsx4Q4TSgmy
# ASOMTUhlzm0SqP76zU3URRj6N//NzxAcOPLlfzxcFPMpWHC9zNlVtFqGtyZi/STj
# B7ed3BOXmddiLNLCL3oJm6rOsidZstKxEs3I1llWjsnltn7fR2/+Fm+roWrF8B4z
# ekQOu9t8WRZfNohKoXVtVuwyUAJQF/8kVtIa2YyxTUAF9co9qVNZgko/nx0gIdxS
# hxmEvQIDAQABo4IBNzCCATMwHwYDVR0jBBgwFoAUdQmmFROuhzz6c5QA8vD1ebmy
# chQwQQYDVR0fBDowODA2oDSgMoYwaHR0cDovL2NybC5kaXNhLm1pbC9jcmwvRE9E
# SURDQV81OV9OQ09ERVNJR04uY3JsMA4GA1UdDwEB/wQEAwIHgDAWBgNVHSAEDzAN
# MAsGCWCGSAFlAgELKjAdBgNVHQ4EFgQUVusXc6nN92xmQ3XNN+/76hosJFEwZQYI
# KwYBBQUHAQEEWTBXMDMGCCsGAQUFBzAChidodHRwOi8vY3JsLmRpc2EubWlsL3Np
# Z24vRE9ESURDQV81OS5jZXIwIAYIKwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2Eu
# bWlsMB8GA1UdJQQYMBYGCisGAQQBgjcKAw0GCCsGAQUFBwMDMA0GCSqGSIb3DQEB
# CwUAA4IBAQBCSdogBcOfKqyGbKG45lLicG1LJ2dmt0Hwl7QkKrZNNEDh2Q2+uzB7
# SRmADtSOVjVf/0+1B4jBoyty90WL52rMPVttb8tfm0f/Wgw6niz5WQZ+XjFRTFQa
# M7pBNU54vI3bH4MFBTXUOEoSr0FELFQaByUWfWKrGLnEqYtpDde5FZEYKRv6td6N
# ZH7m5JOiCfEK6gun3luq7ckvx5zIXjr5VKhp+S0Aai3ZR/eqbBZ0wcUF3DOYlqVs
# LiPT0jWompwkfSnxa3fjNHD+FKvd/7EMQM/wY0vZyIObto3QYrLru6COAyY9cC/s
# Dj+R4K4392w1LWdo3KrNzkCFMAX6j/bWMIIEuTCCA6GgAwIBAgICAwUwDQYJKoZI
# hvcNAQELBQAwWzELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVu
# dDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFjAUBgNVBAMTDURvRCBSb290
# IENBIDMwHhcNMTkwNDAyMTMzODMyWhcNMjUwNDAyMTMzODMyWjBaMQswCQYDVQQG
# EwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAK
# BgNVBAsTA1BLSTEVMBMGA1UEAxMMRE9EIElEIENBLTU5MIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAzBeEny3BCletEU01Vz8kRy8cD2OWvbtwMTyunFaS
# hu+kIk6g5VRsnvbhK3Ho61MBmlGJc1pLSONGBhpbpyr2l2eONAzmi8c8917V7Bpn
# JZvYj66qGRmY4FXX6UZQ6GdALKKedJKrMQfU8LmcBJ/LGcJ0F4635QocGs9UoFS5
# hLgVyflDTC/6x8EPbi/JXk6N6iod5JIAxNp6qW/5ZBvhiuMo19oYX5LuUy9B6W7c
# A0cRygvYcwKKYK+cIdBoxAj34yw2HJI8RQt490QPGClZhz0WYFuNSnUJgTHsdh2V
# NEn2AEe2zYhPFNlCu3gSmOSp5vxpZWbMIQ8cTv4pRWG47wIDAQABo4IBhjCCAYIw
# HwYDVR0jBBgwFoAUbIqUonexgHIdgXoWqvLczmbuRcAwHQYDVR0OBBYEFHUJphUT
# roc8+nOUAPLw9Xm5snIUMA4GA1UdDwEB/wQEAwIBhjBnBgNVHSAEYDBeMAsGCWCG
# SAFlAgELJDALBglghkgBZQIBCycwCwYJYIZIAWUCAQsqMAsGCWCGSAFlAgELOzAM
# BgpghkgBZQMCAQMNMAwGCmCGSAFlAwIBAxEwDAYKYIZIAWUDAgEDJzASBgNVHRMB
# Af8ECDAGAQH/AgEAMAwGA1UdJAQFMAOAAQAwNwYDVR0fBDAwLjAsoCqgKIYmaHR0
# cDovL2NybC5kaXNhLm1pbC9jcmwvRE9EUk9PVENBMy5jcmwwbAYIKwYBBQUHAQEE
# YDBeMDoGCCsGAQUFBzAChi5odHRwOi8vY3JsLmRpc2EubWlsL2lzc3VlZHRvL0RP
# RFJPT1RDQTNfSVQucDdjMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1p
# bDANBgkqhkiG9w0BAQsFAAOCAQEAOQUb0g6nPvWoc1cJ5gkhxSyGA3bQKu8HnKbg
# +vvMpMFEwo2p30RdYHGvA/3GGtrlhxBqAcOqeYF5TcXZ4+Fa9CbKE/AgloCuTjEY
# t2/0iaSvdw7y9Vqk7jyT9H1lFIAQHHN3TEwN1nr7HEWVkkg41GXFxU01UHfR7vgq
# TTz+3zZL2iCqADVDspna0W5pF6yMla6gn4u0TmWu2SeqBpctvdcfSFXkzQBZGT1a
# D/W2Fv00KwoQgB2l2eiVk56mEjN/MeI5Kp4n57mpREsHutP4XnLQ01ZN2qgn+844
# JRrzPQ0pazPYiSl4PeI2FUItErA6Ob/DPF0ba2y3k4dFkUTApzGCAhQwggIQAgEB
# MGIwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEMMAoG
# A1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS01OQIE
# AwIE1zANBglghkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAA
# MBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgor
# BgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCD8q5pBEgDnoCGbfH1bzmTWxjanLy0A
# v/LlM/Z96SPo/TANBgkqhkiG9w0BAQEFAASCAQBYD6D5gr3VHCemSXDaURg5h5e7
# wOQh7iFWVNULySwssun06YM7m2FymwTLFvtk8+l+T6zW/kumoxwbBwfZEgQWw9yR
# 2AB+JTlXY2z0An5j5peeo0+uGy9MkEXrKjDbuiHbGAmvHr8aCmmmidNmjutV1c0h
# FB57BciX5UkOoYBueb7K1kjfadIYtIvNtWwoC23aH1LWfP3+KFxT4EKRgw9L7L+5
# N4tSipwZsOSbTc+S8nH5vDo7+sgxrKWdbl8zmy4S05QXt9UGhfs/ZrZgR+owgOQ7
# t86o/1DpSzm3+oUtqln5LvYEk+usgchNYK1MnJuFF044uMQmCJuClQNlIAl9
# SIG # End signature block
