############################################
# Splunk functions for Evaluate-STIG #
############################################

Function Get-SplunkParameters {
    Param (
      [Parameter(Mandatory = $true)]
      [String]$SplunkHECName,

      [Parameter(Mandatory = $true)]
      [psobject]$ScanObject,

      [Parameter(Mandatory = $true)]
      [array]$OutputPayload,

      [Parameter(Mandatory = $true)]
      [String]$ScriptRoot,

      [Parameter(Mandatory = $true)]
      [String]$WorkingDir,

      [Parameter(Mandatory = $true)]
      [String]$LogComponent,

      [Parameter(Mandatory = $true)]
      [String]$OSPlatform,

      [Parameter(Mandatory = $true)]
      [String]$LogPath
    )

    Write-Log -Path $LogPath -Message "Importing to Splunk..." -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

    #Get Preferences
    $Preferences = (Select-Xml -Path $(Join-Path $ScriptRoot -ChildPath Preferences.xml) -XPath /).Node

    ForEach ($Item in ($Preferences.Preferences.Splunk | Get-Member -MemberType Property | Where-Object Definition -MATCH string | Where-Object Name -NE '#comment').Name) {
        $Preferences.Preferences.Splunk.$Item = $Preferences.Preferences.Splunk.$Item -replace '"','' -replace "'",''
    }

    Try {
      if ($Preferences.Preferences.Splunk | Select-Object -ExpandProperty Splunk_HECName | Where-Object Name -EQ $SplunkHECName){
        $SplunkObject = $Preferences.Preferences.Splunk | Select-Object -ExpandProperty Splunk_HECName | Where-Object Name -EQ $SplunkHECName
        Write-Log -Path $LogPath -Message "Splunk Event Collector: $SplunkHECName" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        Write-Log -Path $LogPath -Message "Importing to Splunk..." -WriteOutToStream -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

        Switch ($OSPlatform) {
          "Windows" {
              $TempLogDir = Join-Path -Path (Get-Item $env:TEMP).FullName -ChildPath "Evaluate-STIG"
          }
          "Linux" {
              $TempLogDir = "/tmp/Evaluate-STIG"
          }
        }

        $STIGLog_Splunk = Join-Path -Path $TempLogDir -ChildPath "Evaluate-STIG_Splunk.log"

        $Splunk_Params = @{
            LogPath                = $STIGLog_Splunk
            OSPlatform             = $OSPlatform
            Splunk_URI             = $($Preferences.Preferences.Splunk.Splunk_URI)
            Splunk_HEC             = $SplunkObject
            Splunk_Payload         = $OutputPayload
            Scan_Objects           = $ScanObject
        }

        Return $Splunk_Params
      }
    }
    Catch {
        Write-Log -Path $LogPath -Message "ERROR: $($_.Exception.Message)" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform

        Throw "Failed to import Splunk Preferences."
    }
  }

  Function Import-Event {
    Param (
      [Parameter(Mandatory = $true)]
      [String]$LogPath,

      [Parameter(Mandatory = $true)]
      [ValidateSet("Windows", "Linux")]
      [String]$OSPlatform,

      [Parameter(Mandatory = $true)]
      [String]$Splunk_URI,

      [Parameter(Mandatory = $true)]
      $Splunk_HEC,

      [Parameter(Mandatory = $true)]
      [array]$Splunk_Payload,

      [Parameter(Mandatory = $true)]
      [psobject]$Scan_Objects,

      [Parameter(Mandatory=$false)]
      [int]$MaximumRetryCount = 3
    )

    $Body_Array = New-Object System.Collections.Generic.List[System.Object]
    $HECOptionList = New-Object System.Collections.Generic.List[System.Object]

    $JSON_POST = Format-Object -ScanObject $Scan_Objects -OutputPayload $Splunk_Payload

    Foreach ($node in $Splunk_HEC.SelectNodes("*")){
      if ($null -ne $Node.'#text'){
          $HECOptionList.Add($Node.Name)
      }
    }

    $JSON_POST | Foreach-Object {
      $body = [ordered]@{
        time            = [DateTimeOffset]::Now.ToUnixTimeSeconds()
        host            = $_.HostName
        event           = $_
      }

      Switch ($HECOptionList){
        "Splunk_index"          {$body.Add("index",$Splunk_HEC.Splunk_index)}
        "Splunk_source"         {$body.Add("source",$Splunk_HEC.Splunk_source)}
        "Splunk_sourcetype"     {$body.Add("sourcetype",$Splunk_HEC.Splunk_sourcetype)}
      }

      $null = $Body_Array.Add($body)
    }

    $Header = @{Authorization="Splunk $($Splunk_HEC.Splunk_token)"}

    Try {
      Write-Host "    Attempting upload of $(($Scan_Objects | Measure-Object).Count) Events..." -ForegroundColor DarkYellow
      $null = Invoke-RestMethod -Uri $Splunk_URI -Headers $Header -ContentType 'application/json' -Body (ConvertTo-Json -InputObject $Body_Array -Depth 4) -Method POST -SkipHTTPErrorCheck -MaximumRetryCount $MaximumRetryCount
    }
    catch {
      Write-Log -Path $LogPath -Message "ERROR: Unable to send event, aborting..." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
      return
    }

  }

# SIG # Begin signature block
# MIIL+QYJKoZIhvcNAQcCoIIL6jCCC+YCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAaWH9cWJ+29gg3
# I98p/u5eOVtWWiQ5cYoXk72No/4nr6CCCTswggR6MIIDYqADAgECAgQDAgTXMA0G
# CSqGSIb3DQEBCwUAMFoxCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVy
# bm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0Qg
# SUQgQ0EtNTkwHhcNMjAwNzE1MDAwMDAwWhcNMjUwNDAyMTMzODMyWjBpMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMRYwFAYDVQQDEw1DUy5OU1dDQ0Qu
# MDAxMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2/Z91ObHZ009DjsX
# ySa9T6DbT+wWgX4NLeTYZwx264hfFgUnIww8C9Mm6ht4mVfo/qyvmMAqFdeyhXiV
# PZuhbDnzdKeXpy5J+oxtWjAgnWwJ983s3RVewtV063W7kYIqzj+Ncfsx4Q4TSgmy
# ASOMTUhlzm0SqP76zU3URRj6N//NzxAcOPLlfzxcFPMpWHC9zNlVtFqGtyZi/STj
# B7ed3BOXmddiLNLCL3oJm6rOsidZstKxEs3I1llWjsnltn7fR2/+Fm+roWrF8B4z
# ekQOu9t8WRZfNohKoXVtVuwyUAJQF/8kVtIa2YyxTUAF9co9qVNZgko/nx0gIdxS
# hxmEvQIDAQABo4IBNzCCATMwHwYDVR0jBBgwFoAUdQmmFROuhzz6c5QA8vD1ebmy
# chQwQQYDVR0fBDowODA2oDSgMoYwaHR0cDovL2NybC5kaXNhLm1pbC9jcmwvRE9E
# SURDQV81OV9OQ09ERVNJR04uY3JsMA4GA1UdDwEB/wQEAwIHgDAWBgNVHSAEDzAN
# MAsGCWCGSAFlAgELKjAdBgNVHQ4EFgQUVusXc6nN92xmQ3XNN+/76hosJFEwZQYI
# KwYBBQUHAQEEWTBXMDMGCCsGAQUFBzAChidodHRwOi8vY3JsLmRpc2EubWlsL3Np
# Z24vRE9ESURDQV81OS5jZXIwIAYIKwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2Eu
# bWlsMB8GA1UdJQQYMBYGCisGAQQBgjcKAw0GCCsGAQUFBwMDMA0GCSqGSIb3DQEB
# CwUAA4IBAQBCSdogBcOfKqyGbKG45lLicG1LJ2dmt0Hwl7QkKrZNNEDh2Q2+uzB7
# SRmADtSOVjVf/0+1B4jBoyty90WL52rMPVttb8tfm0f/Wgw6niz5WQZ+XjFRTFQa
# M7pBNU54vI3bH4MFBTXUOEoSr0FELFQaByUWfWKrGLnEqYtpDde5FZEYKRv6td6N
# ZH7m5JOiCfEK6gun3luq7ckvx5zIXjr5VKhp+S0Aai3ZR/eqbBZ0wcUF3DOYlqVs
# LiPT0jWompwkfSnxa3fjNHD+FKvd/7EMQM/wY0vZyIObto3QYrLru6COAyY9cC/s
# Dj+R4K4392w1LWdo3KrNzkCFMAX6j/bWMIIEuTCCA6GgAwIBAgICAwUwDQYJKoZI
# hvcNAQELBQAwWzELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVu
# dDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFjAUBgNVBAMTDURvRCBSb290
# IENBIDMwHhcNMTkwNDAyMTMzODMyWhcNMjUwNDAyMTMzODMyWjBaMQswCQYDVQQG
# EwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAK
# BgNVBAsTA1BLSTEVMBMGA1UEAxMMRE9EIElEIENBLTU5MIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAzBeEny3BCletEU01Vz8kRy8cD2OWvbtwMTyunFaS
# hu+kIk6g5VRsnvbhK3Ho61MBmlGJc1pLSONGBhpbpyr2l2eONAzmi8c8917V7Bpn
# JZvYj66qGRmY4FXX6UZQ6GdALKKedJKrMQfU8LmcBJ/LGcJ0F4635QocGs9UoFS5
# hLgVyflDTC/6x8EPbi/JXk6N6iod5JIAxNp6qW/5ZBvhiuMo19oYX5LuUy9B6W7c
# A0cRygvYcwKKYK+cIdBoxAj34yw2HJI8RQt490QPGClZhz0WYFuNSnUJgTHsdh2V
# NEn2AEe2zYhPFNlCu3gSmOSp5vxpZWbMIQ8cTv4pRWG47wIDAQABo4IBhjCCAYIw
# HwYDVR0jBBgwFoAUbIqUonexgHIdgXoWqvLczmbuRcAwHQYDVR0OBBYEFHUJphUT
# roc8+nOUAPLw9Xm5snIUMA4GA1UdDwEB/wQEAwIBhjBnBgNVHSAEYDBeMAsGCWCG
# SAFlAgELJDALBglghkgBZQIBCycwCwYJYIZIAWUCAQsqMAsGCWCGSAFlAgELOzAM
# BgpghkgBZQMCAQMNMAwGCmCGSAFlAwIBAxEwDAYKYIZIAWUDAgEDJzASBgNVHRMB
# Af8ECDAGAQH/AgEAMAwGA1UdJAQFMAOAAQAwNwYDVR0fBDAwLjAsoCqgKIYmaHR0
# cDovL2NybC5kaXNhLm1pbC9jcmwvRE9EUk9PVENBMy5jcmwwbAYIKwYBBQUHAQEE
# YDBeMDoGCCsGAQUFBzAChi5odHRwOi8vY3JsLmRpc2EubWlsL2lzc3VlZHRvL0RP
# RFJPT1RDQTNfSVQucDdjMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1p
# bDANBgkqhkiG9w0BAQsFAAOCAQEAOQUb0g6nPvWoc1cJ5gkhxSyGA3bQKu8HnKbg
# +vvMpMFEwo2p30RdYHGvA/3GGtrlhxBqAcOqeYF5TcXZ4+Fa9CbKE/AgloCuTjEY
# t2/0iaSvdw7y9Vqk7jyT9H1lFIAQHHN3TEwN1nr7HEWVkkg41GXFxU01UHfR7vgq
# TTz+3zZL2iCqADVDspna0W5pF6yMla6gn4u0TmWu2SeqBpctvdcfSFXkzQBZGT1a
# D/W2Fv00KwoQgB2l2eiVk56mEjN/MeI5Kp4n57mpREsHutP4XnLQ01ZN2qgn+844
# JRrzPQ0pazPYiSl4PeI2FUItErA6Ob/DPF0ba2y3k4dFkUTApzGCAhQwggIQAgEB
# MGIwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEMMAoG
# A1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS01OQIE
# AwIE1zANBglghkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAA
# MBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgor
# BgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCDF11RLt94VX4SE/QZ2nrDBg9oSzGUI
# +pqwXretXz6SgTANBgkqhkiG9w0BAQEFAASCAQBb3BES+hNjNo1jWhVFEO1PKZQj
# nULDj6PYyR0+ZUIiioSqZ5YIWcGP0di4//qZ2fiCBqftYNFsSf8N2lo1qqdcGoIe
# f4bjWC4arR+rGMb+b2uKeSoYf5YQEfckS7ZUkcrH05BVFYjEHSJk0IDWCLEdFEmz
# WcXkOLh+WLiDy/IfDiWrosYrBAJfXbxw8FVj5bJDQ4jI0ma2CoQpAit7wGVUMFGf
# X92u3vS5LM0NchZuGeEE/FYAJ5S4MoPCiI6sX5K5yZIA3S3d75DV/MslcF2HzWEf
# LR3aZhceJ3eUR+V3Zvhk8QxIoZQlfv+IPC0vcdIaaOJoozKSYY7GqHae9Nuj
# SIG # End signature block
