<#
    .Synopsis
    Create a HTML report for specified Answer File(S)
    .DESCRIPTION
    Creates a HTML report from Evaluate-STIG Answer Files.
    .EXAMPLE
    PS C:\> Get-AnswerfileSummary.ps1 -AFPath C:\Evaluate-STIG\AnswerFiles
    .EXAMPLE
    PS C:\> Get-AnswerfileSummary.ps1 -AFFile C:\Evaluate-STIG\AnswerFiles\Windows_10_Answerfile.xml
    .INPUTS
    -AFPath
        Path to the Evaluate-STIG Answer File directory.
    .INPUTS
    -AFFile
        Path to the Evaluate-STIG Answer File.
    .INPUTS
    -OutputPath
        Path to location to save Summary Report.
#>

Param (
    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [String[]]$AFPath,

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [String[]]$AFFile,

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [String]$OutPutpath
)

Function Convert-AFFile {
    Param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]$AFFile,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]$OutPutpath
    )

    [xml]$AFTransform = @'
<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
     <xsl:template match="/STIGComments">
          <html>
               <head>
                    <style type="text/css">
                         .styled-table {
                              border-collapse: collapse;
                              margin: 25px 0;
                              font-size: 0.9em;
                              font-family: sans-serif;
                              min-width: 400px;
                              box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
                              width: 100%
                         }
                         .styled-table thead tr {
                              background-color: #2E86C1;
                              color: #ffffff;
                              text-align: left;
                         }
                         .styled-table th,
                         .styled-table td {
                              padding: 12px 15px;
                         }
                         .styled-table tbody tr {
                              border-bottom: thin solid #dddddd;
                         }
                         .styled-table tbody tr:last-of-type {
                              border-bottom: 2px solid #3498DB;
                         }
                         .styled-table tbody tr.active-row {
                              font-weight: bold;
                              color: #3498DB;
                         }
                         .hidden {
                              visibility: hidden;
                         }
                         .button {
                              color: #494949 !important;
                              text-align: center;
                              text-transform: uppercase;
                              text-decoration: none;
                              backgrond: #AED6F1;
                              background-color: #AED6F1;
                              padding: 20px;
                              border: 4px solid #494949 !important;
                              display: inline-block;
                              transition: all 0.4s ease 0s;
                              width: 250px;
                              height: 20px;
                              margin: 5px;
                         }
                         .stig_button {
                              color: #494949 !important;
                              text-align: center;
                              text-transform: uppercase;
                              text-decoration: none;
                              backgrond: #ffffff;
                              padding: 20px;
                              border: 4px solid #494949 !important;
                              display: inline-block;
                              transition: all 0.4s ease 0s;
                              width: 450px;
                              height: 10px;
                         }
                         .button:hover{
                              color: #ffffff !important;
                              background: #f6b93b;
                              border-color: #f6b93b !important;
                              transition: all 0.4s ease 0s;
                              cursor: pointer;
                         }
                         .stig_button:hover{
                              color: #ffffff !important;
                              background: #f6b93b;
                              border-color: #f6b93b !important;
                              transition: all 0.4s ease 0s;
                              cursor: pointer;
                         }
                         #topbtn{
                              position: fixed;
                              bottom: 20px;
                              right: 30px;
                              z-index: 99;
                              font-size: 18px;
                              border: none;
                              outline: none;
                              background-color: red;
                              color: white;
                              cursor: pointer;
                              padding: 15px;
                              border-radius: 4px;
                         }
                         #topbtn:hover{
                              background-color: #555;
                         }
                         code {
                             background-color: #eef;
                             display: block;
                         }
                    </style>
                    <script>
                         var topbutton = document.getElementById("topbtn");
                         window.onscroll = function() {scrollFunction()};

                         function scrollFunction() {
                              if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                                   topbutton.style.display = "block";
                              } else {
                                   topbutton.style.display = "none";
                              }
                         }
                         function topFunction() {
                              document.body.scrollTop = 0;
                              document.documentElement.scrollTop = 0;
                         }
                         function change(table_value) {
                              var x = document.getElementById(table_value);
                              if (x.style.display === "none") {
                                   x.style.display = "table";
                              } else {
                                   x.style.display = "none";
                              }
                         }
                    </script>
               </head>
               <body>
                    <button onclick="topFunction()" id="topbtn" title="Go to Top">Top</button>
                    <h1 align="center"><xsl:value-of select="@Name" /> STIG Answer File</h1>
                    <p><!--**************************************************************************************<br />
                        <b>This file contains answers for known opens and findings that cannot be evaluated through technical means.<br />
                        <b>&lt;STIGComments Name&gt;</b> must match the STIG name in STIGList.xml.  When a match is found, this answer file will automatically for the STIG.<br />
                        <b>&lt;Vuln ID&gt;</b> is the STIG VulnID.  Multiple Vuln ID sections may be specified in a single Answer File.<br />
                        <b>&lt;AnswerKey Name&gt;</b> is the name of the key assigned to the answer.  "DEFAULT" can be used to apply the comment to any asset.  Multiple AnswerKey Name sections may be configured within a single Vuln ID section.<br />
                        <b> *Note: If the Answer Key matches the hostname *exactly*, it will supersede any other key for the Vulnerability ID.<br />
                        <b>  Multiple hostnames can be used, separated by either a space or a comma.<br />
                        <b>&lt;ExpectedStatus&gt;</b> is the initial status after the checklist is created.  Valid entries are "Not_Reviewed", "Open", "NotAFinding", and "Not_Applicable".<br />
                        <b>&lt;ValidationCode&gt;</b> must be Powershell code that returns a True/False value.  If blank, "true" is assumed.<br />
                        <b> *Note: If Validation Code returns a PSCustomObject, the Object MUST contain both "Results" and "Valid" keys.  "Results" will be written to the Comments field of the STIG check.<br />
                        <b>&lt;ValidTrueStatus&gt;</b> is the status the check should be set to if ValidationCode returns "true".  Valid entries are "Not_Reviewed", "Open", "NotAFinding", and "Not_Applicable".  If blank, <b>&lt;ExpectedStatus&gt;</b> is assumed.<br />
                        <b>&lt;ValidTrueComment&gt;</b> is the verbiage to add to the Comments section if ValidationCode returns "true".<br />
                        <b>&lt;ValidFalseStatus&gt;</b> is the status the check should be set to if ValidationCode DOES NOT return "true".  Valid entries are "Not_Reviewed", "Open", "NotAFinding", and "Not_Applicable".  If blank, <b>&lt;ExpectedStatus&gt;</b> is assumed.<br />
                        <b>&lt;ValidFalseComment&gt;</b> is the verbiage to add to the Comments section if ValidationCode DOES NOT return "true".<br />
                        <br />
                        **************************************************************************************--></p>
                </body>
            </html>
        <xsl:for-each select="Vuln">
                <tbody><tr>
                    <td><div class="button_cont"><a class="stig_button" id="button" onclick="change('{@ID}')" title="Show/Hide {@ID}"><xsl:value-of select="@ID" /></a></div></td>
                </tr></tbody>
                    <td><table id="{@ID}" class="styled-table" style="display:none">
                        <thead><tr>
                            <th>Name</th>
                            <th>Expected Status</th>
                            <th>Validation Code</th>
                            <th>Valid True Status</th>
                            <th>Valid True Comment</th>
                            <th>Valid False Status</th>
                            <th>Valid False Comment</th>
                        </tr></thead>
                        <xsl:for-each select="AnswerKey">
                            <tbody><tr>
                                    <td><xsl:value-of select="@Name" /></td>
                                    <td><xsl:value-of select="ExpectedStatus" /></td>
                                    <td><code><xsl:value-of select="ValidationCode" /></code></td>
                                    <td><xsl:value-of select="ValidTrueStatus" /></td>
                                    <td><xsl:value-of select="ValidTrueComment" /></td>
                                    <td><xsl:value-of select="ValidFalseStatus" /></td>
                                    <td><xsl:value-of select="ValidFalseComment" /></td>
                            </tr></tbody>
                        </xsl:for-each>
                    </table></td>
        </xsl:for-each>
     </xsl:template>
</xsl:stylesheet>
'@

    $AFxslt = New-Object System.Xml.Xsl.XslCompiledTransform
    $AFxslt.load($AFTransform)
    $AFxslt.Transform($AFFile, $(Join-Path $OutPutpath -ChildPath "$($(Split-Path $AFFile -Leaf).replace('.xml','')).html"))

}

if (!($OutPutpath)) {
    $OutPutpath = $PSScriptRoot
}

$Answerfiles = New-Object -TypeName "System.Collections.ArrayList"
$Answerfiles = [System.Collections.ArrayList]@()

if ($AFPath){
    $Answerfiles += $(Get-ChildItem -Path $AFPath -File).FullName
}

if ($AFFile){
    $AFFile | ForEach-Object {
        if ($(Split-Path $_ -Leaf) -notin $(Split-Path $Answerfiles -Leaf)) {
            $Answerfiles += ($_)
        }
        else{
            Write-Host "Duplicate $(Split-Path $_ -Leaf) found in $AFPath.  Skipping."
        }
    }
}

$Answerfiles | Foreach-Object {
    Convert-AFFile -AFFile $_ -OutPutpath $OutPutpath
}

# SIG # Begin signature block
# MIIL+QYJKoZIhvcNAQcCoIIL6jCCC+YCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBWCEQCOMv+vyTs
# NIU0lnRAnRds4aNQD/qLWcf+yIIFX6CCCTswggR6MIIDYqADAgECAgQDAgTXMA0G
# CSqGSIb3DQEBCwUAMFoxCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVy
# bm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0Qg
# SUQgQ0EtNTkwHhcNMjAwNzE1MDAwMDAwWhcNMjUwNDAyMTMzODMyWjBpMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMRYwFAYDVQQDEw1DUy5OU1dDQ0Qu
# MDAxMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2/Z91ObHZ009DjsX
# ySa9T6DbT+wWgX4NLeTYZwx264hfFgUnIww8C9Mm6ht4mVfo/qyvmMAqFdeyhXiV
# PZuhbDnzdKeXpy5J+oxtWjAgnWwJ983s3RVewtV063W7kYIqzj+Ncfsx4Q4TSgmy
# ASOMTUhlzm0SqP76zU3URRj6N//NzxAcOPLlfzxcFPMpWHC9zNlVtFqGtyZi/STj
# B7ed3BOXmddiLNLCL3oJm6rOsidZstKxEs3I1llWjsnltn7fR2/+Fm+roWrF8B4z
# ekQOu9t8WRZfNohKoXVtVuwyUAJQF/8kVtIa2YyxTUAF9co9qVNZgko/nx0gIdxS
# hxmEvQIDAQABo4IBNzCCATMwHwYDVR0jBBgwFoAUdQmmFROuhzz6c5QA8vD1ebmy
# chQwQQYDVR0fBDowODA2oDSgMoYwaHR0cDovL2NybC5kaXNhLm1pbC9jcmwvRE9E
# SURDQV81OV9OQ09ERVNJR04uY3JsMA4GA1UdDwEB/wQEAwIHgDAWBgNVHSAEDzAN
# MAsGCWCGSAFlAgELKjAdBgNVHQ4EFgQUVusXc6nN92xmQ3XNN+/76hosJFEwZQYI
# KwYBBQUHAQEEWTBXMDMGCCsGAQUFBzAChidodHRwOi8vY3JsLmRpc2EubWlsL3Np
# Z24vRE9ESURDQV81OS5jZXIwIAYIKwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2Eu
# bWlsMB8GA1UdJQQYMBYGCisGAQQBgjcKAw0GCCsGAQUFBwMDMA0GCSqGSIb3DQEB
# CwUAA4IBAQBCSdogBcOfKqyGbKG45lLicG1LJ2dmt0Hwl7QkKrZNNEDh2Q2+uzB7
# SRmADtSOVjVf/0+1B4jBoyty90WL52rMPVttb8tfm0f/Wgw6niz5WQZ+XjFRTFQa
# M7pBNU54vI3bH4MFBTXUOEoSr0FELFQaByUWfWKrGLnEqYtpDde5FZEYKRv6td6N
# ZH7m5JOiCfEK6gun3luq7ckvx5zIXjr5VKhp+S0Aai3ZR/eqbBZ0wcUF3DOYlqVs
# LiPT0jWompwkfSnxa3fjNHD+FKvd/7EMQM/wY0vZyIObto3QYrLru6COAyY9cC/s
# Dj+R4K4392w1LWdo3KrNzkCFMAX6j/bWMIIEuTCCA6GgAwIBAgICAwUwDQYJKoZI
# hvcNAQELBQAwWzELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVu
# dDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFjAUBgNVBAMTDURvRCBSb290
# IENBIDMwHhcNMTkwNDAyMTMzODMyWhcNMjUwNDAyMTMzODMyWjBaMQswCQYDVQQG
# EwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAK
# BgNVBAsTA1BLSTEVMBMGA1UEAxMMRE9EIElEIENBLTU5MIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAzBeEny3BCletEU01Vz8kRy8cD2OWvbtwMTyunFaS
# hu+kIk6g5VRsnvbhK3Ho61MBmlGJc1pLSONGBhpbpyr2l2eONAzmi8c8917V7Bpn
# JZvYj66qGRmY4FXX6UZQ6GdALKKedJKrMQfU8LmcBJ/LGcJ0F4635QocGs9UoFS5
# hLgVyflDTC/6x8EPbi/JXk6N6iod5JIAxNp6qW/5ZBvhiuMo19oYX5LuUy9B6W7c
# A0cRygvYcwKKYK+cIdBoxAj34yw2HJI8RQt490QPGClZhz0WYFuNSnUJgTHsdh2V
# NEn2AEe2zYhPFNlCu3gSmOSp5vxpZWbMIQ8cTv4pRWG47wIDAQABo4IBhjCCAYIw
# HwYDVR0jBBgwFoAUbIqUonexgHIdgXoWqvLczmbuRcAwHQYDVR0OBBYEFHUJphUT
# roc8+nOUAPLw9Xm5snIUMA4GA1UdDwEB/wQEAwIBhjBnBgNVHSAEYDBeMAsGCWCG
# SAFlAgELJDALBglghkgBZQIBCycwCwYJYIZIAWUCAQsqMAsGCWCGSAFlAgELOzAM
# BgpghkgBZQMCAQMNMAwGCmCGSAFlAwIBAxEwDAYKYIZIAWUDAgEDJzASBgNVHRMB
# Af8ECDAGAQH/AgEAMAwGA1UdJAQFMAOAAQAwNwYDVR0fBDAwLjAsoCqgKIYmaHR0
# cDovL2NybC5kaXNhLm1pbC9jcmwvRE9EUk9PVENBMy5jcmwwbAYIKwYBBQUHAQEE
# YDBeMDoGCCsGAQUFBzAChi5odHRwOi8vY3JsLmRpc2EubWlsL2lzc3VlZHRvL0RP
# RFJPT1RDQTNfSVQucDdjMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1p
# bDANBgkqhkiG9w0BAQsFAAOCAQEAOQUb0g6nPvWoc1cJ5gkhxSyGA3bQKu8HnKbg
# +vvMpMFEwo2p30RdYHGvA/3GGtrlhxBqAcOqeYF5TcXZ4+Fa9CbKE/AgloCuTjEY
# t2/0iaSvdw7y9Vqk7jyT9H1lFIAQHHN3TEwN1nr7HEWVkkg41GXFxU01UHfR7vgq
# TTz+3zZL2iCqADVDspna0W5pF6yMla6gn4u0TmWu2SeqBpctvdcfSFXkzQBZGT1a
# D/W2Fv00KwoQgB2l2eiVk56mEjN/MeI5Kp4n57mpREsHutP4XnLQ01ZN2qgn+844
# JRrzPQ0pazPYiSl4PeI2FUItErA6Ob/DPF0ba2y3k4dFkUTApzGCAhQwggIQAgEB
# MGIwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEMMAoG
# A1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS01OQIE
# AwIE1zANBglghkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAA
# MBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgor
# BgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCBxRbsKbOZbtiEYpXeHWmrvGHqv+Fe6
# ZNiqXbiisIW8yjANBgkqhkiG9w0BAQEFAASCAQBM3cdUEZcmKJakJruLcSm/59QO
# 3dzKai1zmJ/BehasWp6GI40F91JfW8P0bqfkkaPpCj0Lb7m/ikKmZVuOkpTjKplQ
# kz7XfO36hveyttxO6lVR+x6R3CkZ4oS9C7P//Qljde1jA/ho4tWzMKg/ukCRqgTZ
# 9yzeug90Tjdeb1TT090+savYXv0en5w1yho1kugJubtvqfrlzPam3S+FQxmOShDU
# HDSVKkj6/I5C57yI3A6+OhIbdBGOJNiCTEXvbhidaEW3AFw3NA/8w9m1DYDXApmF
# t6EGpFlRzhI/p8j9kMXhqyUnUTGEEJ0ghEI5sWpmmd7JmEbyytq+CLhoG2au
# SIG # End signature block
